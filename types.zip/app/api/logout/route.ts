import { NextResponse } from "next/server";
import { cerrarSesion } from "@/lib/auth";

export async function POST() {
  try {
    await cerrarSesion();

    return NextResponse.json({
      ok: true,
      mensaje: "Sesión cerrada correctamente.",
    });
  } catch (error) {
    console.error("Error al cerrar sesión:", error);

    return NextResponse.json(
      {
        ok: false,
        mensaje: "No fue posible cerrar la sesión.",
      },
      { status: 500 }
    );
  }
}