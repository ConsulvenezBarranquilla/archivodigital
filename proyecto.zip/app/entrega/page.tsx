"use client";

import {
    useEffect,
    useMemo,
    useState,
} from "react";

import SistemaLayout from "@/components/layout/SistemaLayout";

import DataTable, {
    TableColumn,
} from "@/components/table/DataTable";

import {
    CategoriaDocumento,
    ReporteEntregado,
} from "@/types/ReporteEntregado";

import {
    MODULOS,
} from "@/lib/modulos";

// ======================================================
// Respuesta API
// ======================================================

interface EntregaResponse {

    ok: boolean;

    total: number;

    pendientes?: number;

    entregados?: number;

    documentos: ReporteEntregado[];

    error?: string;

}

// ======================================================
// Modo de búsqueda
// ======================================================

type ModoBusqueda =
    | "NOMBRE"
    | "DOCUMENTO";

// ======================================================
// Categorías
// ======================================================

const ETIQUETAS_CATEGORIA:
    Record<CategoriaDocumento, string> = {

    PASAPORTES:
        "Pasaportes",

    VISA:
        "Visas",

    APOSTILLA:
        "Apostillas",

    FE_VIDA:
        "Fe de Vida",

    CARTA_SOLTERIA:
        "Carta de Soltería",

    CERTIFICADO_USO:
        "Certificado de Uso",

    CONSTANCIA_REGISTRO:
        "Constancia de Registro",

    CONSTANCIA_CONSULAR:
        "Constancia Consular",

    PODER:
        "Poderes",

    AUTORIZACION_VIAJE:
        "Autorización de Viaje",

};

const MESES = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];

function anioDeFecha(fecha: string | undefined): number | null {
    const valor = String(fecha ?? "").trim();
    const iso = valor.match(/^(\d{4})[-/]/);
    if (iso) return Number(iso[1]);
    const diaMesAnio = valor.match(/^\d{1,2}[/-]\d{1,2}[/-](\d{4})/);
    if (diaMesAnio) return Number(diaMesAnio[1]);
    const parsed = new Date(valor);
    return Number.isNaN(parsed.getTime()) ? null : parsed.getFullYear();
}

function fechaDelDocumentoEntrega(documento: ReporteEntregado): string {
    if (documento.categoria === "CONSTANCIA_CONSULAR" && documento.estado === "MANUAL") {
        return documento.fechaConstancia || documento.fechaRecibo;
    }
    return documento.fechaRecibo;
}

// ======================================================
// Página
// ======================================================

export default function EntregaPage() {

    // ==================================================
    // DOCUMENTOS
    // ==================================================

    const [
        documentos,
        setDocumentos,
    ] = useState<ReporteEntregado[]>([]);

    const [
        cargando,
        setCargando,
    ] = useState(true);

    const [
        error,
        setError,
    ] = useState("");

    // ==================================================
    // MODO DE BÚSQUEDA
    // ==================================================

    const [
        modoBusqueda,
        setModoBusqueda,
    ] = useState<ModoBusqueda | null>(
        null
    );

    // ==================================================
    // BÚSQUEDA PRINCIPAL
    //
    // NOMBRE:
    //   búsqueda por nombre
    //
    // DOCUMENTO:
    //   búsqueda por documento de identidad
    // ==================================================

    const [
        busqueda,
        setBusqueda,
    ] = useState("");

    // ==================================================
    // FILTRO POR NOMBRE
    //
    // Se utiliza solamente en modo DOCUMENTO.
    // ==================================================

    const [
        filtroNombre,
        setFiltroNombre,
    ] = useState("");

    const [filtroMes, setFiltroMes] = useState("");
    const [filtroEdad, setFiltroEdad] = useState<"TODOS" | "NNA" | "ADULTO">("TODOS");
    const [anioFiltro, setAnioFiltro] = useState(String(new Date().getFullYear()));
    const aniosDisponibles = useMemo(() => Array.from(new Set([new Date().getFullYear(), ...documentos
        .map(documento => anioDeFecha(fechaDelDocumentoEntrega(documento)))
        .filter((anio): anio is number => anio !== null)])).sort((a, b) => b - a), [documentos]);

    // ==================================================
    // FILTRO POR CATEGORÍA
    // ==================================================

    const [
        categoria,
        setCategoria,
    ] = useState<
        CategoriaDocumento | "TODOS"
    >("TODOS");

    // ==================================================
// FILTRO POR ESTADO DE ENTREGA
// ==================================================

const [
    filtroEstado,
    setFiltroEstado,
] = useState<
    "TODOS" | "PENDIENTES" | "ENTREGADOS" | "CORREO" | "RECHAZADOS"
>("TODOS");

    // ==================================================
    // ENTREGA
    // ==================================================

    const [
        confirmando,
        setConfirmando,
    ] = useState<ReporteEntregado | null>(
        null
    );

    const [
        entregandoId,
        setEntregandoId,
    ] = useState<string | null>(
        null
    );

    // ==================================================
    // USUARIO
    // ==================================================

    const [
        usuario,
        setUsuario,
    ] = useState("");

    // ==================================================
    // OBTENER USUARIO
    // ==================================================

    useEffect(() => {

        try {

            const usuarioGuardado =
                localStorage.getItem(
                    "usuarioCaja"
                );

            if (!usuarioGuardado) {
                return;
            }

            try {

                const datos =
                    JSON.parse(
                        usuarioGuardado
                    );

                setUsuario(
                    datos?.nombre ??
                    usuarioGuardado
                );

            }

            catch {

                setUsuario(
                    usuarioGuardado
                );

            }

        }

        catch (error) {

            console.error(
                "No fue posible obtener el usuario:",
                error
            );

        }

    }, []);

    // ==================================================
    // CARGAR DOCUMENTOS
    // ==================================================

    async function cargarDocumentos() {

        try {

            setCargando(true);

            setError("");

            const response =
                await fetch(
                    "/api/entrega",
                    {
                        cache:
                            "no-store",
                    }
                );

            const data:
                EntregaResponse =
                await response.json();

            if (
                !response.ok ||
                !data.ok
            ) {

                throw new Error(
                    data.error ||
                    "No fue posible cargar los documentos."
                );

            }

            setDocumentos(
                data.documentos || []
            );

        }

        catch (error: any) {

            console.error(
                "Error cargando documentos:",
                error
            );

            setError(
                error?.message ||
                "No fue posible cargar los documentos."
            );

            setDocumentos([]);

        }

        finally {

            setCargando(false);

        }

    }

    useEffect(() => {

        cargarDocumentos();

    }, []);

    // ==================================================
    // OBTENER VALORES DE BÚSQUEDA
    // ==================================================

    function valoresBusqueda(
        documento: ReporteEntregado
    ): string[] {

        const valores: string[] = [

            documento.solicitante ?? "",

            documento.documento ?? "",

            documento.titularPasaporte ?? "",

            documento.numeroPasaporte ?? "",

            documento.titularVisa ?? "",

            documento.pasaporteTitularVisa ?? "",

            documento.titularApostilla ?? "",

            documento.menor ?? "",

            documento.pasaporteMenor ?? "",

            documento.acompanante ?? "",

            documento.pasaporteAcompanante ?? "",

        ];

        // ==================================================
        // PODERES
        // ==================================================

        if (
            Array.isArray(
                documento.solicitantesPoder
            )
        ) {

            documento.solicitantesPoder.forEach(
                item => {

                    valores.push(
                        item.nombre ?? "",
                        item.documento ?? ""
                    );

                }
            );

        }

        if (
            Array.isArray(
                documento.apoderadosPoder
            )
        ) {

            documento.apoderadosPoder.forEach(
                item => {

                    valores.push(
                        item.nombre ?? "",
                        item.documento ?? ""
                    );

                }
            );

        }

        // ==================================================
        // AUTORIZACIÓN DE VIAJE
        // ==================================================

        if (
            Array.isArray(
                documento.solicitantesAutorizacion
            )
        ) {

            documento.solicitantesAutorizacion.forEach(
                item => {

                    valores.push(
                        item.nombre ?? "",
                        item.documento ?? ""
                    );

                }
            );

        }

        return valores
            .filter(Boolean)
            .map(
                valor =>
                    String(valor)
                        .trim()
                        .toLowerCase()
            );

    }

    function claveMes(fecha: string | undefined): string {
        const valor = String(fecha ?? "").trim();
        const iso = valor.match(/^(\d{4})[-/](\d{1,2})/);
        if (iso) return `${iso[1]}-${iso[2].padStart(2, "0")}`;
        const diaMesAnio = valor.match(/^\d{1,2}[/-](\d{1,2})[/-](\d{4})/);
        if (diaMesAnio) return `${diaMesAnio[2]}-${diaMesAnio[1].padStart(2, "0")}`;
        const fechaParseada = new Date(valor);
        return Number.isNaN(fechaParseada.getTime())
            ? ""
            : `${fechaParseada.getFullYear()}-${String(fechaParseada.getMonth() + 1).padStart(2, "0")}`;
    }

    // ==================================================
    // OBTENER TITULAR PARA MOSTRAR
    // ==================================================

    function obtenerTitular(
        documento: ReporteEntregado
    ): string {

        // ----------------------------------------------
        // Pasaportes
        // ----------------------------------------------

        if (
            documento.categoria ===
            "PASAPORTES"
        ) {

            return (
                documento.titularPasaporte ||
                documento.solicitante ||
                "-"
            );

        }

        // ----------------------------------------------
        // Apostillas
        // ----------------------------------------------

        if (
            documento.categoria ===
            "APOSTILLA"
        ) {

            return (
                documento.titularApostilla ||
                documento.solicitante ||
                "-"
            );

        }

        // ----------------------------------------------
        // Visa
        // ----------------------------------------------

        if (
            documento.categoria ===
            "VISA"
        ) {

            return (
                documento.titularVisa ||
                documento.solicitante ||
                "-"
            );

        }

        // ----------------------------------------------
        // Autorización de viaje
        // ----------------------------------------------

        if (
            documento.categoria ===
            "AUTORIZACION_VIAJE"
        ) {

            return (
                documento.menor ||
                documento.solicitante ||
                "-"
            );

        }

        // ----------------------------------------------
        // Resto
        // ----------------------------------------------

        return (
            documento.solicitante ||
            "-"
        );

    }

    // ==================================================
// FILTRAR DOCUMENTOS SIN APLICAR ESTADO
//
// Aquí se aplican:
// - modo de búsqueda
// - nombre
// - documento
// - categoría
//
// NO se aplica todavía:
// - pendientes
// - entregados
//
// Esto permite que los contadores siempre
// representen el total real del resultado.
// ==================================================

const documentosFiltradosBase =
    useMemo(() => {

        // ==================================================
        // No se ha seleccionado búsqueda
        // ==================================================

        if (!modoBusqueda) {

            return [];

        }

        let resultado = documentos.filter(documento =>
            anioDeFecha(fechaDelDocumentoEntrega(documento)) === Number(anioFiltro)
        );

        // ==================================================
        // BUSCAR POR NOMBRE
        //
        // Se muestran TODOS los documentos de la persona,
        // tanto pendientes como entregados.
        // ==================================================

        if (
            modoBusqueda ===
            "NOMBRE"
        ) {

            const texto =
                busqueda
                    .trim()
                    .toLowerCase();

            if (!texto) {

                return [];

            }

            resultado =
                resultado.filter(
                    documento =>

                        valoresBusqueda(
                            documento
                        ).some(
                            valor =>
                                valor.includes(
                                    texto
                                )
                        )
                );

            return resultado;

        }

        // ==================================================
        // BUSCAR POR DOCUMENTO
        // ==================================================

        // ----------------------------------------------
        // Categoría
        // ----------------------------------------------

        if (
            categoria !==
            "TODOS"
        ) {

            resultado =
                resultado.filter(
                    documento =>

                        documento.categoria ===
                        categoria
                );

        }

        // ----------------------------------------------
        // Filtro por nombre
        // ----------------------------------------------

        const textoNombre =
            filtroNombre
                .trim()
                .toLowerCase();

        if (
            textoNombre
        ) {

            resultado =
                resultado.filter(
                    documento =>

                        valoresBusqueda(
                            documento
                        ).some(
                            valor =>
                                valor.includes(
                                    textoNombre
                                )
                        )
                );

        }

        // ----------------------------------------------
        // Documento de identidad
        // ----------------------------------------------

        const textoDocumento =
            busqueda
                .trim()
                .toLowerCase();

        if (
            textoDocumento
        ) {

            resultado =
                resultado.filter(
                    documento =>

                        valoresBusqueda(
                            documento
                        ).some(
                            valor =>
                                valor.includes(
                                    textoDocumento
                                )
                        )
                );

        }

        if (filtroMes) {
            resultado = resultado.filter(documento => claveMes(fechaDelDocumentoEntrega(documento)).endsWith(`-${filtroMes}`));
        }

        if (filtroEdad !== "TODOS") {
            resultado = resultado.filter(documento => {
                const esNna = String(documento.codigoActuacion ?? "").toUpperCase().includes("NNA") || documento.tipoDocumento === "PASAPORTE_NNA";
                return filtroEdad === "NNA" ? esNna : !esNna;
            });
        }

        return resultado;

    }, [

        documentos,

        modoBusqueda,

        busqueda,

        filtroNombre,

        categoria,

        anioFiltro,

        filtroMes,

        filtroEdad,

    ]);


// ==================================================
// APLICAR FILTRO DE ESTADO
// ==================================================

const documentosVisibles =
    useMemo(() => {

        if (
            filtroEstado ===
            "PENDIENTES"
        ) {

            return documentosFiltradosBase.filter(
                documento =>
                    documento.entregado !== true &&
                    documento.estadoProcesamiento !== "RECHAZADA"
            );

        }

        if (
            filtroEstado ===
            "ENTREGADOS"
        ) {

            return documentosFiltradosBase.filter(
                documento =>
                    documento.entregado === true &&
                    documento.metodoEntrega !== "CORREO"
            );

        }

        if (filtroEstado === "CORREO") {
            return documentosFiltradosBase.filter(
                documento => documento.entregado === true && documento.metodoEntrega === "CORREO"
            );
        }

        if (filtroEstado === "RECHAZADOS") {
            return documentosFiltradosBase.filter(
                documento => documento.estadoProcesamiento === "RECHAZADA"
            );
        }

        return documentosFiltradosBase;

    }, [

        documentosFiltradosBase,

        filtroEstado,

    ]);


// ==================================================
// CONTADORES
//
// IMPORTANTE:
// Se calculan sobre documentosFiltradosBase,
// NO sobre documentosVisibles.
//
// Así permanecen estables al hacer clic.
// ==================================================

const totalPendientes =
    useMemo(() => {

        return documentosFiltradosBase.filter(

            documento =>

                documento.entregado !== true &&
                documento.estadoProcesamiento !== "RECHAZADA"

        ).length;

    }, [

        documentosFiltradosBase,

    ]);


const totalEntregados =
    useMemo(() => {

        return documentosFiltradosBase.filter(

            documento =>

                documento.entregado === true &&
                documento.metodoEntrega !== "CORREO"

        ).length;

    }, [

        documentosFiltradosBase,

    ]);

const totalCorreo = useMemo(() => documentosFiltradosBase.filter(
    documento => documento.entregado === true && documento.metodoEntrega === "CORREO"
).length, [documentosFiltradosBase]);

const totalRechazados = useMemo(() => documentosFiltradosBase.filter(
    documento => documento.estadoProcesamiento === "RECHAZADA"
).length, [documentosFiltradosBase]);

    // ==================================================
    // SELECCIONAR MODO
    // ==================================================

    function seleccionarModo(
    modo: ModoBusqueda
) {

    setModoBusqueda(
        modo
    );

    setBusqueda("");

    setFiltroNombre("");

    setCategoria(
        "TODOS"
    );

    setFiltroMes("");
    setFiltroEdad("TODOS");

    setFiltroEstado(
        "TODOS"
    );

}

    // ==================================================
    // VOLVER A SELECCIÓN
    // ==================================================

    function volverSeleccionBusqueda() {

    setModoBusqueda(
        null
    );

    setBusqueda("");

    setFiltroNombre("");

    setCategoria(
        "TODOS"
    );

    setFiltroMes("");
    setFiltroEdad("TODOS");

    setFiltroEstado(
        "TODOS"
    );

}
// ==================================================
// ALTERNAR FILTRO DE ESTADO
// ==================================================

function alternarFiltroEstado(
    filtro:
        | "PENDIENTES"
        | "ENTREGADOS"
        | "CORREO"
        | "RECHAZADOS"
) {

    setFiltroEstado(
        estadoActual =>

            estadoActual === filtro
                ? "TODOS"
                : filtro
    );

}
    // ==================================================
    // CONFIRMAR ENTREGA
    // ==================================================

    async function confirmarEntrega() {

        if (!confirmando) {

            return;

        }

        if (!usuario) {

            alert(
                "No fue posible identificar el usuario que realiza la entrega."
            );

            return;

        }

        try {

            setEntregandoId(
                confirmando.id
            );

            const fechaEntrega =
                new Date()
                    .toISOString()
                    .substring(
                        0,
                        10
                    );

            // ==================================================
            // REGISTRAR EXCLUSIVAMENTE EN LA API DE ENTREGA
            //
            // IMPORTANTE:
            // No utilizamos marcarEntregado() del servicio
            // ReportesEntregados.
            //
            // Esto mantiene completamente independiente
            // la página reportesentregados/page.tsx.
            // ==================================================

            const response =
                await fetch(
                    "/api/entrega/registrar",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json",
                        },

                        body:
                            JSON.stringify({

                                usuario,

                                documento:
                                    confirmando,

                                fechaEntrega,

                                observaciones:
                                    confirmando.observaciones ??
                                    "",

                            }),

                    }
                );

            const data =
                await response.json();

            if (
                !response.ok ||
                !data.ok
            ) {

                throw new Error(
                    data.error ||
                    "No fue posible registrar la entrega."
                );

            }

            // ==================================================
            // ACTUALIZAR EL ESTADO LOCAL
            //
            // NO eliminamos la fila.
            // ==================================================

            setDocumentos(
                documentosActuales =>

                    documentosActuales.map(
                        documento => {

                            if (
                                documento.id !==
                                confirmando.id
                            ) {

                                return documento;

                            }

                            return {

                                ...documento,

                                entregado:
                                    true,

                                fechaEntrega,

                                entregadoPor:
                                    usuario,

                            };

                        }
                    )

            );

            setConfirmando(
                null
            );

        }

        catch (error: any) {

            console.error(
                "Error registrando entrega:",
                error
            );

            alert(
                error?.message ||
                "No fue posible registrar la entrega."
            );

        }

        finally {

            setEntregandoId(
                null
            );

        }

    }

    // ==================================================
    // COLUMNAS
    // ==================================================

    const columnas:
        TableColumn<ReporteEntregado>[] =
        [

            // ------------------------------------------
            // CATEGORÍA
            // ------------------------------------------

            {

                field:
                    "categoria",

                title:
                    "Tipo de documento",

                render:
                    documento =>

                        ETIQUETAS_CATEGORIA[
                            documento.categoria
                        ] ??
                        documento.categoria,

            },

            // ------------------------------------------
            // TITULAR
            // ------------------------------------------

            {

                field:
                    "solicitante",

                title:
                    "Titular",

                render:
                    documento =>

                        obtenerTitular(
                            documento
                        ),

            },

            // ------------------------------------------
            // DOCUMENTO
            // ------------------------------------------

            {

                field:
                    "documento",

                title:
                    "Documento",

                render:
                    documento =>

                        documento.documento ||
                        "-",

            },

            // ------------------------------------------
            // RECIBO
            // ------------------------------------------

            {

                field:
                    "recibo",

                title:
                    "Recibo",

                render:
                    documento =>

                        documento.recibo ||
                        "-",

            },

            // ------------------------------------------
            // PLANILLA
            // ------------------------------------------

            {

                field:
                    "planillaGC",

                title:
                    "Planilla GC",

                render:
                    documento =>

                        documento.planillaGC ||
                        "-",

            },

            // ------------------------------------------
            // OBSERVACIONES
            // ------------------------------------------

            {

                field:
                    "observaciones",

                title:
                    "Observaciones",

                whiteSpace:
                    "pre-line",

                render:
                    documento =>

                        documento.observaciones ||
                        "-",

            },

            // ------------------------------------------
            // ESTADO
            // ------------------------------------------

            {

                field:
                    "estadoProcesamiento",

                title:
                    "Estado",

                align:
                    "center",

                render:
                    documento => {

                        const procesando =
                            entregandoId ===
                            documento.id;

                        if (documento.estadoProcesamiento === "RECHAZADA") {
                            return (
                                <span className="inline-flex items-center justify-center rounded-xl bg-red-100 px-4 py-2 font-semibold text-red-800 whitespace-nowrap">
                                    Rechazado
                                </span>
                            );
                        }

                        // ==================================
                        // ENTREGADO
                        // ==================================

                        if (documento.entregado && documento.metodoEntrega === "CORREO") {

                            return (
                                <span className="inline-flex items-center justify-center px-4 py-2 rounded-xl bg-violet-600 text-white font-semibold whitespace-nowrap">
                                    Enviado por Correo
                                </span>
                            );
                        }

                        if (documento.entregado) {

                            return (

                                <span
                                    className="
                                        inline-flex
                                        items-center
                                        justify-center
                                        px-4
                                        py-2
                                        rounded-xl
                                        bg-emerald-600
                                        text-white
                                        font-semibold
                                        whitespace-nowrap
                                    "
                                >

                                    Entregado

                                </span>

                            );

                        }

                        // ==================================
                        // PENDIENTE
                        // ==================================

                        return (

                            <button

                                type="button"

                                disabled={
                                    procesando
                                }

                                onClick={() =>
                                    setConfirmando(
                                        documento
                                    )
                                }

                                className={`
                                    px-4
                                    py-2
                                    rounded-xl
                                    font-semibold
                                    text-white
                                    whitespace-nowrap
                                    transition
                                    ${
                                        procesando
                                            ? "bg-slate-400"
                                            : "bg-blue-600 hover:bg-blue-700"
                                    }
                                `}

                            >

                                {
                                    procesando

                                        ? "Procesando..."

                                        : "Pendiente por entrega"

                                }

                            </button>

                        );

                    },

            },
// ------------------------------------------
// FUNCIONARIO QUE ENTREGÓ
// ------------------------------------------

{
    field:
        "entregadoPor",

    title:
        "Funcionario que entregó",

    render:
        documento =>

            documento.entregadoPor ||
            "-",

},
{
    field: "fechaEntrega",
    title: "Fecha de entrega",
    render: documento => {
        const fecha = String(documento.fechaEntrega || documento.fechaEnvioCorreo || "").trim();
        if (!fecha) return "-";
        const iso = fecha.match(/^(\d{4})-(\d{2})-(\d{2})/);
        if (iso) return `${iso[3]}/${iso[2]}/${iso[1]}`;
        const diaMesAnio = fecha.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})/);
        return diaMesAnio ? `${diaMesAnio[1].padStart(2, "0")}/${diaMesAnio[2].padStart(2, "0")}/${diaMesAnio[3]}` : fecha;
    },
},
        ];

    // ==================================================
    // RENDER
    // ==================================================

    return (

        <SistemaLayout

            titulo="
                Entrega de documentos
            "

            permiso={
                MODULOS.CAJA
            }

        >

            <div className="
                space-y-6
            ">

                {/* ======================================
                    ENCABEZADO
                ======================================= */}

                <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">

                    <div>

                    <h1 className="
                        text-2xl
                        font-bold
                        text-blue-950
                    ">

                        Entrega de documentos

                    </h1>

                    <p className="
                        mt-1
                        text-slate-500
                    ">

                        Consulte y registre la entrega
                        de documentos procesados.

                    </p>

                    </div>

                    <label className="flex shrink-0 items-center gap-3 text-sm font-semibold text-slate-700">
                        Año
                        <select value={anioFiltro} onChange={e => setAnioFiltro(e.target.value)} disabled={cargando} className="min-w-28 rounded-xl border border-slate-300 bg-white px-4 py-2 font-semibold outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-slate-100">
                            {(aniosDisponibles.length ? aniosDisponibles : [new Date().getFullYear()]).map(anio => <option key={anio} value={anio}>{anio}</option>)}
                        </select>
                    </label>

                </div>

                {/* ======================================
                    SELECCIÓN INICIAL
                ======================================= */}

                {
                    !modoBusqueda && (

                        <div className="
                            bg-white
                            border
                            rounded-2xl
                            shadow-sm
                            p-6
                        ">

                            <h2 className="
                                text-lg
                                font-semibold
                                text-slate-800
                            ">

                                Buscar documentos

                            </h2>

                            <p className="
                                mt-1
                                text-sm
                                text-slate-500
                            ">

                                Seleccione cómo desea localizar
                                los documentos del ciudadano.

                            </p>

                            <div className="
                                mt-5
                                grid
                                grid-cols-1
                                md:grid-cols-2
                                gap-4
                            ">

                                {/* ==========================
                                    POR NOMBRE
                                =========================== */}

                                <button

                                    type="button"

                                    onClick={() =>
                                        seleccionarModo(
                                            "NOMBRE"
                                        )
                                    }

                                    className="
                                        rounded-2xl
                                        border
                                        border-blue-200
                                        bg-blue-50
                                        px-6
                                        py-6
                                        text-left
                                        hover:bg-blue-100
                                        transition
                                    "

                                >

                                    <div className="
                                        text-lg
                                        font-semibold
                                        text-blue-900
                                    ">

                                        Buscar por nombre

                                    </div>

                                    <div className="
                                        mt-2
                                        text-sm
                                        text-slate-600
                                    ">

                                        Encuentre todos los documentos
                                        asociados al ciudadano.

                                    </div>

                                </button>

                                {/* ==========================
                                    POR DOCUMENTO
                                =========================== */}

                                <button

                                    type="button"

                                    onClick={() =>
                                        seleccionarModo(
                                            "DOCUMENTO"
                                        )
                                    }

                                    className="
                                        rounded-2xl
                                        border
                                        border-slate-300
                                        bg-slate-50
                                        px-6
                                        py-6
                                        text-left
                                        hover:bg-slate-100
                                        transition
                                    "

                                >

                                    <div className="
                                        text-lg
                                        font-semibold
                                        text-slate-800
                                    ">

                                        Buscar por documento

                                    </div>

                                    <div className="
                                        mt-2
                                        text-sm
                                        text-slate-600
                                    ">

                                        Consulte la tabla y filtre
                                        por documento, nombre o tipo.

                                    </div>

                                </button>

                            </div>

                        </div>

                    )
                }

                {/* ======================================
                    MODO NOMBRE
                ======================================= */}

                {
                    modoBusqueda ===
                    "NOMBRE" && (

                        <div className="
                            bg-white
                            border
                            rounded-2xl
                            shadow-sm
                            p-5
                        ">

                            <div className="
                                flex
                                flex-col
                                md:flex-row
                                md:items-center
                                md:justify-between
                                gap-4
                            ">

                                <div>

                                    <h2 className="
                                        text-lg
                                        font-semibold
                                        text-slate-800
                                    ">

                                        Buscar por nombre

                                    </h2>

                                    <p className="
                                        text-sm
                                        text-slate-500
                                    ">

                                        Se mostrarán los documentos
                                        pendientes y entregados
                                        asociados al ciudadano.

                                    </p>

                                </div>

                                <button

                                    type="button"

                                    onClick={
                                        volverSeleccionBusqueda
                                    }

                                    className="
                                        px-4
                                        py-2
                                        rounded-xl
                                        border
                                        border-slate-300
                                        bg-white
                                        hover:bg-slate-50
                                    "

                                >

                                    Cambiar búsqueda

                                </button>

                            </div>

                            <div className="
                                mt-5
                            ">

                                <input

                                    type="text"

                                    autoFocus

                                    value={
                                        busqueda
                                    }

                                    onChange={e =>
                                        setBusqueda(
                                            e.target.value
                                        )
                                    }

                                    placeholder="
                                        Escriba el nombre del ciudadano
                                    "

                                    className="
                                        w-full
                                        border
                                        border-slate-300
                                        rounded-xl
                                        px-4
                                        py-3
                                        outline-none
                                        focus:ring-2
                                        focus:ring-blue-500
                                    "

                                />

                            </div>

                        </div>

                    )
                }

                {/* ======================================
                    MODO DOCUMENTO
                ======================================= */}

                {
                    modoBusqueda ===
                    "DOCUMENTO" && (

                        <div className="
                            bg-white
                            border
                            rounded-2xl
                            shadow-sm
                            p-5
                        ">

                            <div className="
                                flex
                                flex-col
                                md:flex-row
                                md:items-center
                                md:justify-between
                                gap-4
                            ">

                                <div>

                                    <h2 className="
                                        text-lg
                                        font-semibold
                                        text-slate-800
                                    ">

                                        Buscar por documento

                                    </h2>

                                    <p className="
                                        text-sm
                                        text-slate-500
                                    ">

                                        Consulte los documentos
                                        procesados.

                                    </p>

                                </div>

                                <button

                                    type="button"

                                    onClick={
                                        volverSeleccionBusqueda
                                    }

                                    className="
                                        px-4
                                        py-2
                                        rounded-xl
                                        border
                                        border-slate-300
                                        bg-white
                                        hover:bg-slate-50
                                    "

                                >

                                    Cambiar búsqueda

                                </button>

                            </div>

                            <div className="
                                mt-5
                                grid
                                grid-cols-1
                                md:grid-cols-5
                                gap-4
                            ">

                                {/* ==========================
                                    DOCUMENTO
                                =========================== */}

                                <div>

                                    <label className="
                                        block
                                        text-sm
                                        font-semibold
                                        mb-2
                                    ">

                                        Documento de identidad

                                    </label>

                                    <input

                                        type="text"

                                        value={
                                            busqueda
                                        }

                                        onChange={e =>
                                            setBusqueda(
                                                e.target.value
                                            )
                                        }

                                        placeholder="
                                            Cédula o pasaporte
                                        "

                                        className="
                                            w-full
                                            border
                                            border-slate-300
                                            rounded-xl
                                            px-4
                                            py-3
                                            outline-none
                                            focus:ring-2
                                            focus:ring-blue-500
                                        "

                                    />

                                </div>

                                {/* ==========================
                                    NOMBRE
                                =========================== */}

                                <div>

                                    <label className="
                                        block
                                        text-sm
                                        font-semibold
                                        mb-2
                                    ">

                                        Nombre

                                    </label>

                                    <input

                                        type="text"

                                        value={
                                            filtroNombre
                                        }

                                        onChange={e =>
                                            setFiltroNombre(
                                                e.target.value
                                            )
                                        }

                                        placeholder="
                                            Filtrar por nombre
                                        "

                                        className="
                                            w-full
                                            border
                                            border-slate-300
                                            rounded-xl
                                            px-4
                                            py-3
                                            outline-none
                                            focus:ring-2
                                            focus:ring-blue-500
                                        "

                                    />

                                </div>

                                {/* ==========================
                                    CATEGORÍA
                                =========================== */}

                                <div>

                                    <label className="
                                        block
                                        text-sm
                                        font-semibold
                                        mb-2
                                    ">

                                        Tipo de documento

                                    </label>

                                    <select

                                        value={
                                            categoria
                                        }

                                        onChange={e =>
                                            setCategoria(
                                                e.target.value as
                                                CategoriaDocumento |
                                                "TODOS"
                                            )
                                        }

                                        className="
                                            w-full
                                            border
                                            border-slate-300
                                            rounded-xl
                                            px-4
                                            py-3
                                            bg-white
                                            outline-none
                                            focus:ring-2
                                            focus:ring-blue-500
                                        "

                                    >

                                        <option value="TODOS">

                                            Todos

                                        </option>

                                        {
                                            (
                                                Object.keys(
                                                    ETIQUETAS_CATEGORIA
                                                ) as
                                                CategoriaDocumento[]
                                            ).map(
                                                item => (

                                                    <option
                                                        key={item}
                                                        value={item}
                                                    >

                                                        {
                                                            ETIQUETAS_CATEGORIA[
                                                                item
                                                            ]
                                                        }

                                                    </option>

                                                )
                                            )
                                        }

                                    </select>

                                </div>

                                <div>
                                    <label className="mb-2 block text-sm font-semibold">Mes del documento</label>
                                    <select value={filtroMes} onChange={e => setFiltroMes(e.target.value)} className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500">
                                        <option value="">Todos los meses</option>
                                        {MESES.map((mes, indice) => <option key={mes} value={String(indice + 1).padStart(2, "0")}>{mes}</option>)}
                                    </select>
                                </div>

                                <div>
                                    <label className="mb-2 block text-sm font-semibold">Actuación</label>
                                    <select value={filtroEdad} onChange={e => setFiltroEdad(e.target.value as "TODOS" | "NNA" | "ADULTO")} className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500">
                                        <option value="TODOS">NNA y Adulto</option>
                                        <option value="NNA">NNA</option>
                                        <option value="ADULTO">Adulto</option>
                                    </select>
                                </div>

                            </div>

                        </div>

                    )
                }

                {/* ======================================
                    CONTADORES
                ======================================= */}

                {
                    modoBusqueda && (

                        <div className="
                            grid
                            grid-cols-1
                            md:grid-cols-2
                            xl:grid-cols-4
                            gap-4
                        ">

                            {/* ==========================
                                PENDIENTES
                            =========================== */}

                           <button
    type="button"
    onClick={() =>
        alternarFiltroEstado(
            "PENDIENTES"
        )
    }
    className={`
        w-full
        text-left
        bg-white
        border
        rounded-2xl
        shadow-sm
        p-5
        transition-all
        duration-200
        cursor-pointer
        hover:shadow-md
        ${
            filtroEstado ===
            "PENDIENTES"
                ? "border-blue-600 ring-2 ring-blue-200 bg-blue-50"
                : "border-slate-200"
        }
    `}
>

    <div className="
        text-sm
        text-slate-500
    ">

        Documentos pendientes por entregar

    </div>

    <div className="
        mt-1
        text-3xl
        font-bold
        text-blue-700
    ">

        {
            totalPendientes
        }

    </div>

</button>

                            {/* ==========================
                                ENTREGADOS
                            =========================== */}

                            <button
    type="button"
    onClick={() =>
        alternarFiltroEstado(
            "ENTREGADOS"
        )
    }
    className={`
        w-full
        text-left
        bg-white
        border
        rounded-2xl
        shadow-sm
        p-5
        transition-all
        duration-200
        cursor-pointer
        hover:shadow-md
        ${
            filtroEstado ===
            "ENTREGADOS"
                ? "border-emerald-600 ring-2 ring-emerald-200 bg-emerald-50"
                : "border-slate-200"
        }
    `}
>

    <div className="
        text-sm
        text-slate-500
    ">

        Documentos entregados

    </div>

    <div className="
        mt-1
        text-3xl
        font-bold
        text-emerald-600
    ">

        {
            totalEntregados
        }

    </div>

</button>

                            <button
                                type="button"
                                onClick={() => alternarFiltroEstado("CORREO")}
                                className={`w-full text-left bg-white border rounded-2xl shadow-sm p-5 transition-all duration-200 cursor-pointer hover:shadow-md ${filtroEstado === "CORREO" ? "border-violet-600 ring-2 ring-violet-200 bg-violet-50" : "border-slate-200"}`}
                            >
                                <div className="text-sm text-slate-500">Enviados por correo</div>
                                <div className="mt-1 text-3xl font-bold text-violet-600">{totalCorreo}</div>
                            </button>

                            <button
                                type="button"
                                onClick={() => alternarFiltroEstado("RECHAZADOS")}
                                className={`w-full text-left bg-white border rounded-2xl shadow-sm p-5 transition-all duration-200 cursor-pointer hover:shadow-md ${filtroEstado === "RECHAZADOS" ? "border-red-600 ring-2 ring-red-200 bg-red-50" : "border-slate-200"}`}
                            >
                                <div className="text-sm text-slate-500">Rechazados</div>
                                <div className="mt-1 text-3xl font-bold text-red-600">{totalRechazados}</div>
                            </button>

                        </div>

                    )
                }

                {/* ======================================
                    RESULTADO
                ======================================= */}

                {
                    modoBusqueda && (

                        <div className="
                            flex
                            items-center
                            justify-between
                            gap-4
                        ">

                            <div className="
                                text-sm
                                text-slate-600
                            ">

                                {
                                    documentosVisibles.length
                                }

                                {" "}

                                {
                                    documentosVisibles.length === 1
                                        ? "documento encontrado"
                                        : "documentos encontrados"
                                }

                            </div>

                            <button

                                type="button"

                                onClick={
                                    cargarDocumentos
                                }

                                disabled={
                                    cargando
                                }

                                className="
                                    px-4
                                    py-2
                                    rounded-xl
                                    border
                                    border-slate-300
                                    bg-white
                                    hover:bg-slate-50
                                    disabled:opacity-50
                                "

                            >

                                Actualizar

                            </button>

                        </div>

                    )
                }

                {/* ======================================
                    ERROR
                ======================================= */}

                {
                    error && (

                        <div className="
                            rounded-xl
                            border
                            border-red-200
                            bg-red-50
                            text-red-700
                            px-4
                            py-3
                        ">

                            {error}

                        </div>

                    )
                }

                {/* ======================================
                    TABLA
                ======================================= */}

                {
                    modoBusqueda && (

                        <div className="
                            bg-white
                            rounded-2xl
                            border
                            shadow-sm
                            overflow-hidden
                        ">

                            {
                                cargando

                                    ? (

                                        <div className="
                                            p-10
                                            text-center
                                            text-slate-500
                                        ">

                                            Cargando documentos...

                                        </div>

                                    )

                                    : (

                                        <DataTable

                                            columns={
                                                columnas
                                            }

                                            data={
                                                documentosVisibles
                                            }

                                            getRowKey={(
                                                row
                                            ) =>
                                                row.id
                                            }

                                        />

                                    )

                            }

                        </div>

                    )
                }

            </div>

            {/* ==========================================
                POPUP DE CONFIRMACIÓN
            =========================================== */}

            {
                confirmando && (

                    <div className="
                        fixed
                        inset-0
                        z-50
                        bg-black/40
                        flex
                        items-center
                        justify-center
                        p-6
                    ">

                        <div className="
                            bg-white
                            rounded-2xl
                            shadow-2xl
                            w-full
                            max-w-md
                            p-7
                        ">

                            <h2 className="
                                text-xl
                                font-bold
                                text-blue-950
                            ">

                                Confirmar entrega

                            </h2>

                            <p className="
                                mt-4
                                text-slate-700
                                leading-relaxed
                            ">

                                ¿Está seguro de entregar
                                el documento al ciudadano{" "}

                                <strong>

                                    {
                                        obtenerTitular(
                                            confirmando
                                        )
                                    }

                                </strong>

                                ?

                            </p>

                            <div className="
                                mt-7
                                flex
                                justify-end
                                gap-3
                            ">

                                <button

                                    type="button"

                                    disabled={
                                        entregandoId !== null
                                    }

                                    onClick={() =>
                                        setConfirmando(
                                            null
                                        )
                                    }

                                    className="
                                        px-5
                                        py-2
                                        rounded-xl
                                        border
                                        border-slate-300
                                        hover:bg-slate-100
                                        disabled:opacity-50
                                    "

                                >

                                    Cancelar

                                </button>

                                <button

                                    type="button"

                                    disabled={
                                        entregandoId !== null
                                    }

                                    onClick={
                                        confirmarEntrega
                                    }

                                    className="
                                        px-5
                                        py-2
                                        rounded-xl
                                        bg-emerald-600
                                        hover:bg-emerald-700
                                        text-white
                                        font-semibold
                                        disabled:opacity-50
                                    "

                                >

                                    {
                                        entregandoId !== null

                                            ? "Registrando..."

                                            : "Confirmar entrega"
                                    }

                                </button>

                            </div>

                        </div>

                    </div>

                )
            }

        </SistemaLayout>

    );

}
