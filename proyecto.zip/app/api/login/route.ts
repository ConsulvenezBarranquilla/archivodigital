import { NextRequest, NextResponse } from "next/server";
import { obtenerUsuariosCaja } from "@/lib/googleSheets";
import { crearSesion } from "@/lib/auth";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    const usuarioIngresado = String(
      body?.usuario ?? ""
    ).trim();

    const passwordIngresado = String(
      body?.password ?? ""
    ).trim();

    if (!usuarioIngresado || !passwordIngresado) {
      return NextResponse.json(
        {
          ok: false,
          mensaje: "Debe ingresar usuario y contraseña.",
        },
        { status: 400 }
      );
    }

    const rows = await obtenerUsuariosCaja();

    const encontrado = rows.find((row, index) => {
      if (index === 0) return false;

      const usuario = String(row[0] ?? "")
        .trim()
        .toUpperCase();

      const password = String(row[1] ?? "").trim();

      const activo = String(row[4] ?? "")
        .trim()
        .toUpperCase();

      return (
        usuario === usuarioIngresado.toUpperCase() &&
        password === passwordIngresado &&
        activo === "SI"
      );
    });

    if (!encontrado) {
      return NextResponse.json(
        {
          ok: false,
          mensaje: "Usuario o contraseña incorrectos.",
        },
        { status: 401 }
      );
    }

    const usuario = String(
      encontrado[0] ?? ""
    ).trim();

    const nombre = String(
      encontrado[2] ?? ""
    ).trim();

    const rol = String(
      encontrado[3] ?? ""
    )
      .trim()
      .toLowerCase();

    // El administrador entra automáticamente por Caja 1.
    // Puede cambiar de caja más adelante desde el módulo Caja.
    const caja = rol === "admin" ? "Caja 1" : undefined;

    const sesionCreada =
      await crearSesion({
        usuario,
        nombre,
        rol,
        caja,
      });

    if (!sesionCreada) {
      return NextResponse.json(
        {
          ok: false,
          mensaje:
            "Este usuario ya tiene una sesión activa. Debe cerrar la sesión anterior antes de iniciar una nueva.",
        },
        { status: 409 }
      );
    }

    return NextResponse.json({
      ok: true,
      usuario,
      nombre,
      rol,
      ...(caja ? { caja } : {}),
    });
  } catch (error) {
    console.error("Error en login:", error);

    return NextResponse.json(
      {
        ok: false,
        mensaje:
          "No fue posible procesar el inicio de sesión.",
      },
      { status: 500 }
    );
  }
}
